const express = require("express")
const router = express.Router()

const userController = require("../controllers/userController")
const { uploadTicketImages } = require("../controllers/uploadController")
const { userMiddleware } = require("../middleware/userMiddleware");

// const { createTicket } = require("../controllers/ticketController")
// const { uploadImages, debugRaw } = require("../middleware/uploadMiddleware")

router.post("/register",userController.registerUser)
router.post("/check-user", userController.checkUser)
router.get("/me", userMiddleware, userController.getMe)

// ย้ายไป route ticket
// router.post("/create-ticket", createTicket)
// router.post("/tickets/:ticket_id/images",uploadImages,uploadTicketImages)

module.exports = router;  